#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <netdb.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "cs360utils.h"

using namespace std;


#define SOCKET_ERROR        -1
#define BUFFER_SIZE         100
#define MESSAGE             "This is the message I'm sending back and forth"
#define QUEUE_SIZE          5
bool isDir=false;
bool isImg=false;


string Stat(std::string path)
{
 struct stat filestat;
 stringstream ss;
        if(stat(path.c_str(), &filestat)) {
		 ss <<"ERROR in stat\n";
        }
        if(S_ISREG(filestat.st_mode)) {
             
           if(isImg){
		FILE *fp =fopen(path.c_str(),"rb");
		char *buffer= (char *)malloc(filestat.st_size);
                fread(buffer, filestat.st_size, 1, fp);
		ss<<buffer;
		}
	   else{
                FILE *fp= fopen(path.c_str(), "r");
               char *buffer= (char *)malloc(filestat.st_size);
                fread(buffer, filestat.st_size, 1, fp);
		ss<<buffer;
		}

        }
        if(S_ISDIR(filestat.st_mode)) {
		
                 DIR *dirp;
		isDir=true;
  struct dirent *dp;

  dirp = opendir(".");
  while ((dp = readdir(dirp)) != NULL)
    ss<<"<a href=\""<< dp->d_name<<"\">"<<dp->d_name<<"</a>"<<"<br/>";
  (void)closedir(dirp);
        }


//	cout<<"STAT "<<ss.str().c_str()<<endl;
	return ss.str();

}


char *getBuffer(string path){
	struct stat filestat;

		FILE *fp =fopen(path.c_str(),"rb");
                char *buffer= (char *)malloc(filestat.st_size);
                fread(buffer, filestat.st_size, 1, fp);
		return buffer;
}



int getContentLength(string path){
	struct stat filestat;
	if(stat(path.c_str(), &filestat)){
	return -1;
}
return filestat.st_size;
}

string getContents(const char* file){
	std::ifstream in(file, std::ios::in | std::ios::binary);
	if(in){
	string contents;
	in.seekg(0, ios::end);
	contents.resize(in.tellg());
	in.seekg(0, ios::beg);
	in.read(&contents[0], contents.size());
	return contents;
	}
	else{
	return"";
	}	
}

void write_to_socket(int hSocket,string &filetype, string newpath){
  stringstream ss;
	string list=Stat(newpath);
	int length=getContentLength(newpath);
	if(list=="ERROR in stat\n"){
	 ss<<"HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\nContent-Length: 35\r\n\r\n<html><h1>404 NOT FOUND</h1></html>";
        write(hSocket, ss.str().c_str(),ss.str().length());
	}
	else if(isDir){
	isDir=false;
	ss<<"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length"<<length<<" \r\n\r\n"<<list;
	write(hSocket, ss.str().c_str(), ss.str().length()); 	
	}
	else{
	if(isImg){
	cout<<"IS IMAGE"<<endl;
	cout<<"path :"<<newpath<<endl;
	cout<<"Filetype: "<<filetype<<endl;	
	ss<<"HTTP/1.1 200 OK\r\nContent-Type: "<<filetype<<"\r\nContent-Length: ";
	ss<<length<<" \r\n\r\n";
	ss<<getContents(newpath.c_str());
	string msg=ss.str();
	write(hSocket, msg.c_str(), msg.size());
	//write(hSocket,imgBuffer , sizeof(imgBuffer));
	}
	else{
	ss<<"HTTP/1.1 200 OK\r\nContent-Type: "<<filetype<<"\r\nContent-Length"<<length<<" \r\n\r\n<pre>"<<list<<"</pre>";
        write(hSocket, ss.str().c_str(), ss.str().length());
	}
	cout<<"write to socket"<<endl;
	isImg=false;
	}
}

void getContentType(string path, string &filetype){
	if(path.substr(path.find_last_of(".")+1)=="txt"){
		filetype="text/plain";
	}
	if(path.substr(path.find_last_of(".")+1)=="html"){
		filetype="text/html";
	}	
	if(path.substr(path.find_last_of(".")+1)=="jpg"){
		filetype="image/jpg";
		isImg=true;
	}	
	if(path.substr(path.find_last_of(".")+1)=="gif"){
		filetype="image/gif";
		isImg=true;
	}
	cout<<"GET TYPE"<<filetype<<endl;
}

int main(int argc, char* argv[])
{
    int hSocket,hServerSocket;  /* handle to socket */
    struct hostent* pHostInfo;   /* holds info about a machine */
    struct sockaddr_in Address; /* Internet socket address stuct */
    int nAddressSize=sizeof(struct sockaddr_in);
    char pBuffer[BUFFER_SIZE];
    int nHostPort;
    string path;	

    if(argc < 3)
      {
        printf("\nUsage: server host-port file\n");
        return 0;
      }
    else
      {
        nHostPort=atoi(argv[1]);
	path=argv[2];
      }

    printf("\nStarting server");

    printf("\nMaking socket");
    /* make a socket */
    hServerSocket=socket(AF_INET,SOCK_STREAM,0);

    if(hServerSocket == SOCKET_ERROR)
    {
        printf("\nCould not make a socket\n");
        return 0;
    }

    /* fill address struct */
    Address.sin_addr.s_addr=INADDR_ANY;
    Address.sin_port=htons(nHostPort);
    Address.sin_family=AF_INET;

    printf("\nBinding to port %d",nHostPort);

    /* bind to a port */
    if(bind(hServerSocket,(struct sockaddr*)&Address,sizeof(Address)) 
                        == SOCKET_ERROR)
    {
        printf("\nCould not connect to host\n");
        return 0;
    }
 /*  get port number */
    getsockname( hServerSocket, (struct sockaddr *) &Address,(socklen_t *)&nAddressSize);
    printf("opened socket as fd (%d) on port (%d) for stream i/o\n",hServerSocket, ntohs(Address.sin_port) );

        printf("Server\n\
              sin_family        = %d\n\
              sin_addr.s_addr   = %d\n\
              sin_port          = %d\n"
              , Address.sin_family
              , Address.sin_addr.s_addr
              , ntohs(Address.sin_port)
            );


    printf("\nMaking a listen queue of %d elements",QUEUE_SIZE);
    /* establish listen queue */
    if(listen(hServerSocket,QUEUE_SIZE) == SOCKET_ERROR)
    {
        printf("\nCould not listen\n");
        return 0;
    }

    for(;;)
    {   

	string newpath;
	string filetype;
        printf("\nWaiting for a connection\n");
        /* get the connected socket */
        hSocket=accept(hServerSocket,(struct sockaddr*)&Address,(socklen_t *)&nAddressSize);

        printf("\nGot a connection from %X (%d)\n",
              Address.sin_addr.s_addr,
              ntohs(Address.sin_port));
        

	 vector <char*> headers;
        GetHeaderLines(headers, hSocket, false);
        for(int i=0; i<headers.size(); i++){
                cout<<headers[i]<<endl;
        }
cout<<"-----------------------------------------------------------------------------"<<endl;

if(headers.size()>0){
        stringstream ss;
        ss<< headers[0];
        string holder,userPath;
        ss>>holder>>userPath;
	cout<<userPath<<endl;
	newpath=path+userPath;
	cout<<"PATH "<<newpath<<endl;
      //get file type and content length from stat. If directory serve index.html if no index serve directory listings, if file serve conents, if not valid return 
	//404 not found.

	getContentType(newpath, filetype);
	cout<<'\n'<<"CONTENT TYPE "<<filetype<<endl;
	write_to_socket(hSocket,filetype, newpath);
	linger lin;
	unsigned int y=sizeof(lin);
	lin.l_onoff=1;
	lin.l_linger=10;
	setsockopt(hSocket, SOL_SOCKET, SO_LINGER, &lin, sizeof(lin));
}
	shutdown(hSocket, SHUT_RDWR);

    printf("\nClosing the socket");
        /* close socket */
        if(close(hSocket) == SOCKET_ERROR)
        {
         printf("\nCould not close socket\n");
         return 0;
        }
    }
}
