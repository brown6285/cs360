#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <cmath>
#include <iostream>

using namespace std;

#define SOCKET_ERROR        -1
#define BUFFER_SIZE         10000
#define HOST_NAME_SIZE      255
#define NSTD 				3

int  main(int argc, char* argv[])
{
	struct hostent* pHostInfo;
	struct sockaddr_in Address;
	long nHostAddress;
	char pBuffer[BUFFER_SIZE];
	unsigned nReadAmount;
	char strHostName[HOST_NAME_SIZE];
	int nHostPort;
	bool hasD = false;
	int c, count;
	string path;

	while ((c = getopt(argc, argv, "d")) != -1) {
		switch (c) {
			case 'd':
				hasD = true;
				break;
			case '?':
				cout << "Bad Input" << endl;
				return 0;
		}
	}

	strcpy(strHostName, argv[optind]);
	nHostPort = atoi(argv[optind + 1]);
	path = argv[optind + 2];
	count = atoi(argv[optind+3]);

	int hSocket[count];
	struct timeval oldtime[count+NSTD];

	// MAKING SOCKET
	for (int i = 0; i < count; i++) {
		hSocket[i]=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
		if(hSocket[i] == SOCKET_ERROR)
		{
			printf("\nCould not make a socket\n");
			return 0;
		}
	}

	// GET IP ADDRESS FROM NAME
	pHostInfo = gethostbyname(strHostName);

	// COPY INTO LONG
	memcpy(&nHostAddress, pHostInfo->h_addr, pHostInfo->h_length);

	// CONFIG ADDRESS STRUCT
	Address.sin_addr.s_addr = nHostAddress;
	Address.sin_port = htons(nHostPort);
	Address.sin_family = AF_INET;

	int epollFD = epoll_create(1);

	// SEND REQUESTS AND SET UP EPOLL DATA
	for (int i = 0; i < count; i++) {
		// CONNECT TO HOST
		if (connect(hSocket[i], (struct sockaddr*) &Address, sizeof(Address)) == SOCKET_ERROR) {
			printf("\nCould not connect to host\n");
			return 0;
		}
		string request = "GET" + path + "HTTP/1.0\r\n\r\n";

		write(hSocket[i], request.c_str(), strlen(request.c_str()));

		// KEEP TRACK OF THE TIME WHEN WE SENT THE REQUEST
		gettimeofday(&oldtime[hSocket[i]], NULL);

		// TELL EPOLL THAT WE WANT TO KNOW WHEN THIS SOCKET HAS DATA
		struct epoll_event event;
		event.data.fd = hSocket[i];
		event.events = EPOLLIN;
		int ret = epoll_ctl(epollFD, EPOLL_CTL_ADD, hSocket[i], &event);
		if(ret)
			perror ("epoll_ctl");
	}

	double time = 0;
	double times[count];
	for (int i = 0; i < count; i++) {
		struct epoll_event event;
		int rval = epoll_wait(epollFD,&event,1,-1);
		if(rval < 0)
			perror("epoll_wait");

		rval = read(event.data.fd,pBuffer,BUFFER_SIZE);
		struct timeval newtime;
		// GET THE CURRENT TIME AND SUBTRACT THE STARTING TIME FOR THIS REQUEST.
		gettimeofday(&newtime, NULL);
		double usec = (newtime.tv_sec - oldtime[event.data.fd].tv_sec) * (double) 1000000 + (newtime.tv_usec - oldtime[event.data.fd].tv_usec);
		//printf("Got %d from %d\n", rval, event.data.fd);

		time += usec / 1000000;
		times[i] = usec / 1000000;
		if (hasD) {
			cout << "Response time: " << usec / 1000000 << endl;
		}

		// TAKE THIS ONE OUT OF EPOLL
		epoll_ctl(epollFD, EPOLL_CTL_DEL, event.data.fd, &event);
	}

	// CALCULATE AND PRINT OVERALL RESPONSE TIMES 
	double mean = time / count;
	cout << "Average Response Time: " << mean << endl;
	double std_dev = 0;
	for (int i = 0; i < count; i++) {
		double sqrdDiff = (times[i] - mean) * (times[i] - mean);
		std_dev += (times[i] - mean) * (times[i] - mean);
	}
	std_dev = sqrt(std_dev / count);
	cout << "Standard Deviation: " <<std_dev << endl;


	// CLOSE SOCKETS
	for (int i = 0; i < count; i++) {
		// CLOSE SOCKET                        
		if(close(hSocket[i]) == SOCKET_ERROR)
		{
			printf("\nCould not close socket\n");
			return 0; 
		} 
	}
}
